(function($) {
	"use strict";
	
	//P-scrolling
	
	
	const ps2 = new PerfectScrollbar('.menu', {
	  useBothWheelAxes:true,
	  suppressScrollX:true,
	});
	
	
	
	
})(jQuery);