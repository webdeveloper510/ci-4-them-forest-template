<?php // By default leftmenu-icon is activated, if you want to activate any other version of your choice you can just uncomment the below lines according to your version ?>


<?=$this->include('layouts/versions/leftmenu-icon/light');?>
<?php //<?= $this->include('layouts/versions/leftmenu-icon/dark'); ?>
<?php //<?=$this->include('layouts/versions/leftmenu-icon/light-boxed');?>
<?php //<?=$this->include('layouts/versions/leftmenu-icon/dark-boxed');?>


<?php //<?=$this->include('layouts/versions/horizontal/light');?>
<?php //<?= $this->include('layouts/versions/horizontal/dark'); ?>
<?php //<?=$this->include('layouts/versions/horizontal/light-boxed');?>
<?php //<?=$this->include('layouts/versions/horizontal/dark-boxed');?>


<?php //<?=$this->include('layouts/versions/leftmenu-icontext/light');?>
<?php //<?= $this->include('layouts/versions/leftmenu-icontext/dark'); ?>
<?php //<?=$this->include('layouts/versions/leftmenu-icontext/light-boxed');?>
<?php //<?=$this->include('layouts/versions/leftmenu-icontext/dark-boxed');?>


<?php //<?=$this->include('layouts/versions/leftmenu-iconoverlay/light');?>
<?php //<?= $this->include('layouts/versions/leftmenu-iconoverlay/dark'); ?>
<?php //<?=$this->include('layouts/versions/leftmenu-iconoverlay/light-boxed');?>
<?php //<?=$this->include('layouts/versions/leftmenu-iconoverlay/dark-boxed');?>


<?php //<?=$this->include('layouts/versions/leftmenu-closed/light');?>
<?php //<?= $this->include('layouts/versions/leftmenu-closed/dark'); ?>
<?php //<?=$this->include('layouts/versions/leftmenu-closed/light-boxed');?>
<?php //<?=$this->include('layouts/versions/leftmenu-closed/dark-boxed');?>


<?php //<?=$this->include('layouts/versions/leftmenu-toggle/light');?>
<?php //<?= $this->include('layouts/versions/leftmenu-toggle/dark'); ?>
<?php //<?=$this->include('layouts/versions/leftmenu-toggle/light-boxed');?>
<?php //<?=$this->include('layouts/versions/leftmenu-toggle/dark-boxed');?>


<?php //<?=$this->include('layouts/versions/hoversubmenu/light');?>
<?php //<?= $this->include('layouts/versions/hoversubmenu/dark'); ?>
<?php //<?=$this->include('layouts/versions/hoversubmenu/light-boxed');?>
<?php //<?=$this->include('layouts/versions/hoversubmenu/dark-boxed');?>


<?php //<?=$this->include('layouts/versions/hoversubmenu-style/light');?>
<?php //<?= $this->include('layouts/versions/hoversubmenu-style/dark'); ?>
<?php //<?=$this->include('layouts/versions/hoversubmenu-style/light-boxed');?>
<?php //<?=$this->include('layouts/versions/hoversubmenu-style/dark-boxed');?>


<?php //<?=$this->include('layouts/versions/centerlogo/light');?>
<?php //<?= $this->include('layouts/versions/centerlogo/dark'); ?>
<?php //<?=$this->include('layouts/versions/centerlogo/light-boxed');?>
<?php //<?=$this->include('layouts/versions/centerlogo/dark-boxed');?>

