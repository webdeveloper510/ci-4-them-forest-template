<?php // By default leftmenu-icon is activated, if you want to activate any other version of your choice you can just uncomment the below lines according to your version ?>


<?=$this->include('layouts/versions/custom-masters/light');?>
<?php //<?= $this->include('layouts/versions/custom-masters/dark'); ?>
<?php //<?=$this->include('layouts/versions/custom-masters/light-boxed');?>
<?php //<?=$this->include('layouts/versions/custom-masters/dark-boxed');?>