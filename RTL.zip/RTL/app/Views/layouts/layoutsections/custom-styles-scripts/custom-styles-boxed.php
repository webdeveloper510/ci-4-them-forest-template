		<!-- Title -->
		<title> Valex -  Premium dashboard ui bootstrap rwd admin html5 template </title>

		<!-- Favicon -->
		<link rel="icon" href="<?php echo base_url('assets/img/brand/favicon.png'); ?>" type="image/x-icon"/>

		<!-- Bootstrap css-->
		<link href="<?php echo base_url('assets/plugins/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet"/>

		<!-- Icons css -->
		<link href="<?php echo base_url('assets/css-rtl/icons.css'); ?>" rel="stylesheet">

        <!-- P-scroll bar css remove in final -->
		<link href="<?php echo base_url('assets/plugins/perfect-scrollbar/p-scrollbar.css'); ?>" rel="stylesheet" />

		<!-- Style css -->
		<link href="<?php echo base_url('assets/css-rtl/style.css'); ?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/css-rtl/style-dark.css'); ?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/css-rtl/dark-boxed.css'); ?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/css-rtl/boxed.css'); ?>" rel="stylesheet">

        <?= $this->renderSection('custom-styles'); ?>

		<!---Skinmodes css-->
		<link href="<?php echo base_url('assets/css-rtl/skin-modes.css'); ?>" rel="stylesheet" />