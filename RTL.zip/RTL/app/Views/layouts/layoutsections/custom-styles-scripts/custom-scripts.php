		<!-- JQuery min js -->
		<script src="<?php echo base_url('assets/plugins/jquery/jquery.min.js'); ?>"></script>

		<!-- Bootstrap js -->
        <script src="<?php echo base_url('assets/plugins/bootstrap/js/popper.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/plugins/bootstrap/js/bootstrap-rtl.js'); ?>"></script>

		<!-- Ionicons js -->
		<script src="<?php echo base_url('assets/plugins/ionicons/ionicons.js'); ?>"></script>

		<!-- P-scroll js Remove in final -->
		<script src="<?php echo base_url('assets/plugins/perfect-scrollbar/perfect-scrollbar.min-rtl.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/perfect-scrollbar/p-scroll-rtl.js'); ?>"></script>

		<!-- eva-icons js -->
		<script src="<?php echo base_url('assets/js/eva-icons.min.js'); ?>"></script>

		<!-- Rating js-->
		<script src="<?php echo base_url('assets/plugins/rating/jquery.rating-stars.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/rating/jquery.barrating.js'); ?>"></script>

        <?= $this->renderSection('custom-scripts'); ?>

		<!-- custom js -->
		<script src="<?php echo base_url('assets/js/custom.js'); ?>"></script>